const express = require('express');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const app = express();
const upload = multer({storage: multer.memoryStorage()});
app.use(express.json({limit:'2mb'}));
app.use(express.static('.'));

app.post('/api/fetch-results', async (req,res)=>{
  try{
    const {url}=req.body||{};
    if(!url || !/^https?:\/\//i.test(url)) return res.status(400).json({error:'A valid http/https URL is required.'});
    const u=new URL(url);
    const r=await fetch(u,{headers:{'User-Agent':'LottoLab Results Reader/1.0'},redirect:'follow'});
    if(!r.ok) return res.status(502).json({error:`Source returned HTTP ${r.status}.`});
    let text=await r.text();
    text=text.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<noscript[\s\S]*?<\/noscript>/gi,' ')
      .replace(/<\/(tr|p|div|li|h[1-6]|table|br)>/gi,'\n').replace(/<[^>]+>/g,' ')
      .replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>')
      .replace(/\s+\n/g,'\n').replace(/\n\s+/g,'\n').replace(/[ \t]{2,}/g,' ').trim();
    res.json({text,source:url});
  }catch(e){res.status(500).json({error:e.message});}
});
app.post('/api/extract-pdf',upload.single('file'),async(req,res)=>{
  try{
    if(!req.file) return res.status(400).json({error:'No PDF file was uploaded.'});
    const p=await pdfParse(req.file.buffer);
    const text=(p.text||'').trim();
    if(!text) return res.status(422).json({error:'No text could be extracted. This may be a scanned/image PDF and needs OCR.',pages:p.numpages});
    res.json({text,pages:p.numpages});
  }catch(e){res.status(500).json({error:e.message});}
});
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`LottoLab running on ${port}`));

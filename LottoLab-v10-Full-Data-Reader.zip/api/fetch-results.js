// LottoLab website reader endpoint
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({error:'POST required'});
  try {
    const {url} = req.body || {};
    if (!url || !/^https?:\/\//i.test(url)) return res.status(400).json({error:'A valid http/https URL is required.'});
    const u = new URL(url);
    if (!['http:','https:'].includes(u.protocol)) return res.status(400).json({error:'Only http/https URLs are allowed.'});
    const response = await fetch(u.toString(), {
      headers: {'User-Agent':'LottoLab Results Reader/1.0 (+https://vercel.com)'},
      redirect:'follow'
    });
    if (!response.ok) return res.status(502).json({error:`Source returned HTTP ${response.status}.`});
    const contentType = response.headers.get('content-type') || '';
    const text = await response.text();
    // Basic HTML-to-text extraction. Tables remain readable because cell text is preserved.
    const cleaned = text
      .replace(/<script[\s\S]*?<\/script>/gi,' ')
      .replace(/<style[\s\S]*?<\/style>/gi,' ')
      .replace(/<noscript[\s\S]*?<\/noscript>/gi,' ')
      .replace(/<\/(tr|p|div|li|h[1-6]|table|br)>/gi,'\n')
      .replace(/<[^>]+>/g,' ')
      .replace(/&nbsp;/gi,' ')
      .replace(/&amp;/gi,'&')
      .replace(/&lt;/gi,'<')
      .replace(/&gt;/gi,'>')
      .replace(/\s+\n/g,'\n')
      .replace(/\n\s+/g,'\n')
      .replace(/[ \t]{2,}/g,' ')
      .trim();
    return res.status(200).json({text: cleaned, contentType, source:url});
  } catch (e) {
    return res.status(500).json({error:e?.message || 'Website fetch failed.'});
  }
}

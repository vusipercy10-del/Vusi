// LottoLab PDF text extraction endpoint
import Busboy from 'busboy';
import pdfParse from 'pdf-parse';

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({error:'POST required'});
  try {
    const bb = Busboy({headers:req.headers});
    let chunks = [];
    let gotFile = false;
    await new Promise((resolve,reject)=>{
      bb.on('file',(name,file)=>{
        gotFile = true;
        file.on('data',d=>chunks.push(d));
        file.on('end',()=>{});
      });
      bb.on('error',reject);
      bb.on('finish',resolve);
      req.pipe(bb);
    });
    if (!gotFile) return res.status(400).json({error:'No PDF file was uploaded.'});
    const buffer = Buffer.concat(chunks);
    const parsed = await pdfParse(buffer);
    const text = (parsed.text || '').trim();
    if (!text) return res.status(422).json({error:'No text could be extracted. This may be a scanned/image PDF and needs OCR.', pages:parsed.numpages});
    return res.status(200).json({text, pages:parsed.numpages});
  } catch (e) {
    return res.status(500).json({error:e?.message || 'PDF extraction failed.'});
  }
}
